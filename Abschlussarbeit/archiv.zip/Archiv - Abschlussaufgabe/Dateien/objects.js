/*
Aufgabe: Abschlussarbeit
Name: Priska Maier
Matrikel: 256326
Datum: 23.02.18
    
Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.
*/
var Endaufgabe;
(function (Endaufgabe) {
    class Objects {
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
        draw() { }
    }
    Endaufgabe.Objects = Objects;
})(Endaufgabe || (Endaufgabe = {}));
//# sourceMappingURL=objects.js.map